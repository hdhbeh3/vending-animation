import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';

export const Root: React.FC = () => (
  <Composition id="VendingMachine" component={Video} durationInFrames={150} fps={30} width={1080} height={1920} />
);
