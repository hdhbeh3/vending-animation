import * as THREE from 'three';

export const clamp = (v: number, min = 0, max = 1) => Math.max(min, Math.min(max, v));
export const easeOut = (v: number) => { const t = clamp(v); return 1 - Math.pow(1 - t, 3); };

export const camAt = (frame: number) => {
  const t = easeOut(Math.min(frame, 120) / 120);
  const a0 = -0.22;
  const a1 = 0.18;
  const a = a0 + (a1 - a0) * t;
  const radius = 9.4;
  return {
    pos: [Math.sin(a) * radius + 0.1, 4.4 - 0.25 * t, Math.cos(a) * radius + 0.1] as [number, number, number],
    look: [0, 1.72, 0] as [number, number, number],
  };
};

export const makeCamera = (frame: number) => {
  const camera = new THREE.PerspectiveCamera(35, 1080 / 1920, 0.1, 100);
  const {pos, look} = camAt(frame);
  camera.position.set(...pos);
  camera.lookAt(...look);
  camera.updateMatrixWorld();
  camera.updateProjectionMatrix();
  return camera;
};
