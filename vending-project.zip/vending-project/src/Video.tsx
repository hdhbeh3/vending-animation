import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Montserrat';
import * as THREE from 'three';
import {Scene} from './Scene';
import {clamp, easeOut, makeCamera} from './rig';

const {fontFamily} = loadFont('normal', {weights: ['600'], subsets: ['latin']});

type Callout = {label: string; anchor: [number, number, number]; side: 'left' | 'right'; dy: number; start: number};
const CALLOUTS: Callout[] = [
  {label: 'EVAPORATOR FAN', anchor: [-0.3, 3.05, -0.62], side: 'left', dy: -110, start: 82},
  {label: 'SPIRAL COIL', anchor: [0.6, 2.4, 0.2], side: 'right', dy: -90, start: 94},
  {label: 'COMPRESSOR', anchor: [0.35, 0.28, -0.2], side: 'left', dy: 150, start: 106},
];

export const Video = () => {
  const frame = useCurrentFrame();
  const cam = makeCamera(frame);
  const titleIn = easeOut(frame / 18);

  return (
    <AbsoluteFill
      style={{
        backgroundColor: '#0A2A78',
        backgroundImage:
          'linear-gradient(rgba(130,175,255,0.16) 1px, transparent 1px), linear-gradient(90deg, rgba(130,175,255,0.16) 1px, transparent 1px)',
        backgroundSize: '54px 54px',
      }}
    >
      <Scene />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 55%, rgba(0,0,0,0) 45%, rgba(3,12,45,0.75) 100%)'}} />

      <div
        style={{
          position: 'absolute', left: 72, top: 110, width: 700, color: '#fff', fontFamily,
          fontWeight: 600, fontSize: 96, lineHeight: 1.05, letterSpacing: -2,
          opacity: titleIn, transform: `translateY(${(1 - titleIn) * 24}px)`,
        }}
      >
        Inside a Vending Machine
      </div>

      <svg width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
        {CALLOUTS.map((c) => {
          const p = clamp((frame - c.start) / 10);
          if (p <= 0) return null;
          const e = easeOut(p);
          const v = new THREE.Vector3(...c.anchor).project(cam);
          const ax = ((v.x + 1) / 2) * 1080;
          const ay = ((1 - v.y) / 2) * 1920;
          const ey = ay + c.dy;
          const ex = c.side === 'left' ? 150 : 930;
          const tx = c.side === 'left' ? 72 : 1008;
          const len = Math.hypot(ex - ax, ey - ay);
          return (
            <g key={c.label} opacity={e}>
              <line x1={ax} y1={ay} x2={ex} y2={ey} stroke="#fff" strokeWidth={3} strokeDasharray={len} strokeDashoffset={len * (1 - e)} />
              <line x1={ex} y1={ey} x2={tx} y2={ey} stroke="#fff" strokeWidth={3} />
              <circle cx={ax} cy={ay} r={9} fill="#fff" />
              <text
                x={tx} y={ey - 16} fill="#fff" fontFamily={fontFamily} fontWeight={600} fontSize={34} letterSpacing={3}
                textAnchor={c.side === 'left' ? 'start' : 'end'}
              >
                {c.label}
              </text>
            </g>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};
