import {useEffect, useMemo} from 'react';
import {useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {camAt, clamp, easeOut} from './rig';

const WHITE = '#F4F6FA';
const clay = <meshStandardMaterial color={WHITE} roughness={0.92} metalness={0} />;
const clay2 = <meshStandardMaterial color="#DCE1EA" roughness={0.95} />;

const Box = ({p, s, dark}: {p: [number, number, number]; s: [number, number, number]; dark?: boolean}) => (
  <mesh position={p} castShadow>
    <boxGeometry args={s} />
    {dark ? clay2 : clay}
  </mesh>
);

// Cabinet 2 wide (x), 1.6 deep (z), 3.4 tall. Front-right quadrant is cut away.
const Cabinet = () => (
  <group>
    <Box p={[0, 0.03, 0]} s={[2.06, 0.06, 1.66]} />
    <Box p={[0, 1.7, -0.8]} s={[2, 3.4, 0.06]} />
    <Box p={[-1, 1.7, 0]} s={[0.06, 3.4, 1.6]} />
    <Box p={[-0.5, 1.7, 0.8]} s={[1, 3.4, 0.06]} />
    <Box p={[1, 1.7, -0.4]} s={[0.06, 3.4, 0.8]} />
    <Box p={[-0.5, 3.43, 0]} s={[1.06, 0.06, 1.66]} />
    <Box p={[0.5, 3.43, -0.4]} s={[1.06, 0.06, 0.86]} />
    <Box p={[0, 0.72, 0]} s={[1.94, 0.05, 1.54]} />
    {/* keypad + coin panel + dispense flap on the front-left wall */}
    <Box p={[-0.5, 2.0, 0.85]} s={[0.5, 0.9, 0.05]} dark />
    <Box p={[-0.5, 1.4, 0.85]} s={[0.3, 0.12, 0.05]} dark />
    <Box p={[-0.5, 0.45, 0.85]} s={[0.7, 0.25, 0.05]} dark />
  </group>
);

const Coil = ({x, y}: {x: number; y: number}) => {
  const geo = useMemo(() => {
    const pts: THREE.Vector3[] = [];
    for (let i = 0; i <= 90; i++) {
      const t = i / 90;
      const a = t * Math.PI * 2 * 5;
      pts.push(new THREE.Vector3(Math.cos(a) * 0.1, Math.sin(a) * 0.1, -0.55 + t * 1.1));
    }
    return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 160, 0.014, 6, false);
  }, []);
  return (
    <group position={[x, y, 0]}>
      <mesh geometry={geo}>{clay}</mesh>
      {[-0.35, 0.05, 0.4].map((z) => (
        <mesh key={z} position={[0, 0.2, z]}>
          <boxGeometry args={[0.28, 0.4, 0.22]} />
          {clay2}
        </mesh>
      ))}
    </group>
  );
};

const Interior = () => (
  <group>
    {[1.1, 1.7, 2.3, 2.9].map((y) => (
      <group key={y}>
        <Box p={[0, y - 0.12, 0]} s={[1.94, 0.04, 1.5]} />
        {[-0.6, 0, 0.6].map((x) => (
          <Coil key={x} x={x} y={y + 0.02} />
        ))}
      </group>
    ))}
    {/* compressor + condenser block */}
    <mesh position={[0.35, 0.28, -0.2]}>
      <cylinderGeometry args={[0.28, 0.28, 0.45, 32]} />
      {clay}
    </mesh>
    <Box p={[-0.45, 0.3, -0.3]} s={[0.7, 0.42, 0.5]} dark />
    {/* evaporator fan housing, top back */}
    <mesh position={[-0.3, 3.05, -0.62]} rotation={[Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[0.3, 0.3, 0.12, 32]} />
      {clay}
    </mesh>
    <Box p={[-0.3, 3.05, -0.7]} s={[0.7, 0.7, 0.04]} dark />
  </group>
);

const COUNT = 14;
const makeCurves = () =>
  Array.from({length: COUNT}, (_, i) => {
    const u = i / (COUNT - 1) - 0.5;
    const x = u * 1.6;
    return new THREE.CatmullRomCurve3([
      new THREE.Vector3(x * 1.2, 0.35, 1.9),
      new THREE.Vector3(x * 0.8, 0.45, 0.6),
      new THREE.Vector3(x * 0.5 + 0.3, 0.55, -0.2), // squeezed through the compressor
      new THREE.Vector3(x, 1.3, -0.68),
      new THREE.Vector3(x, 2.0, -0.62),
      new THREE.Vector3(x * 0.95, 2.45, -0.1),
      new THREE.Vector3(x * 0.9, 2.55, 0.55),
      new THREE.Vector3(x * 1.1, 3.0, 1.1),
      new THREE.Vector3(x * 1.2, 3.4, 1.9),
    ]);
  });

const ORANGE = new THREE.Color('#FF8A1F');
const RED = new THREE.Color('#B3120F');

const FlowLine = ({curve, head, clock, idx}: {curve: THREE.CatmullRomCurve3; head: number; clock: number; idx: number}) => {
  const geo = useMemo(() => {
    if (head < 0.03) return null;
    const pts = curve.getPoints(120).slice(0, Math.max(3, Math.floor(head * 120)));
    const g = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), pts.length * 2, 0.022, 5, false);
    const pos = g.attributes.position;
    const col = new Float32Array(pos.count * 3);
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const y = pos.getY(i);
      const heat = clamp((1.2 - y) / 0.8); // red near the compressor, orange elsewhere
      c.copy(ORANGE).lerp(RED, heat);
      col.set([c.r, c.g, c.b], i * 3);
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return g;
  }, [curve, head]);
  useEffect(() => () => geo?.dispose(), [geo]);
  if (!geo) return null;
  const pulse = (k: number) => curve.getPoint((((clock * 0.35 + idx * 0.11 + k * 0.5) % 1) * head));
  const tip = curve.getPoint(head);
  return (
    <group>
      <mesh geometry={geo}>
        <meshBasicMaterial vertexColors toneMapped={false} />
      </mesh>
      {[0, 1].map((k) => (
        <mesh key={k} position={pulse(k)}>
          <sphereGeometry args={[0.04, 10, 10]} />
          <meshBasicMaterial color="#FFE2B0" toneMapped={false} />
        </mesh>
      ))}
      <mesh position={tip}>
        <sphereGeometry args={[0.06, 10, 10]} />
        <meshBasicMaterial color="#FFF4DC" toneMapped={false} />
      </mesh>
    </group>
  );
};

const Rig = ({frame}: {frame: number}) => {
  const {camera} = useThree();
  const {pos, look} = camAt(frame);
  camera.position.set(...pos);
  camera.lookAt(...look);
  camera.updateMatrixWorld();
  return null;
};

export const Scene = () => {
  const frame = useCurrentFrame();
  const curves = useMemo(makeCurves, []);
  const clock = easeOut(Math.min(frame, 120) / 120) * 4; // pulses ease to a stop with the camera
  return (
    <ThreeCanvas width={1080} height={1920} camera={{fov: 35, near: 0.1, far: 100}} style={{background: 'transparent'}}>
      <Rig frame={frame} />
      <ambientLight intensity={0.9} />
      <hemisphereLight args={['#BFD4FF', '#1A3C8F', 0.5]} />
      <directionalLight position={[5, 9, 6]} intensity={1.6} />
      <directionalLight position={[-6, 4, -3]} intensity={0.5} color="#9DB8FF" />
      <Cabinet />
      <Interior />
      {curves.map((c, i) => (
        <FlowLine key={i} curve={c} idx={i} clock={clock} head={easeOut((frame - 30 - i * 1.5) / 50)} />
      ))}
    </ThreeCanvas>
  );
};
