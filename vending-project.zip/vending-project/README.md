# Vending machine Remotion project

Claude supplied `package.json`, `Video.tsx`, and `Scene.tsx`. The original code also imports `./rig`, so `src/rig.ts` has been added, along with the Remotion entry point, composition root, TypeScript config, and Remotion config.

## Run locally

1. Install Node.js (LTS).
2. In this folder run: `npm install`
3. Preview: `npm run dev`
4. Render: `npm run render`

The render command writes `out/vending.mp4`.

Note: the project has been scaffolded, but package installation and rendering have not completed in this environment. Preview the first render and adjust camera/callout positions if needed.
