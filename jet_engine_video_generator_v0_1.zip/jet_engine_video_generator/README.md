# 3D Machine Explainer Generator — Jet Engine starter

This is a first working foundation for a vertical 3D explainer rendered on GitHub Actions.

## What it does
- Builds a stylized 3D jet-engine cutaway in Blender.
- Animates the fan, compressor, turbine and hot exhaust.
- Renders a 1080 × 1920, 30 fps MP4.
- Generates an original music/SFX bed and mixes it under your voiceover.
- Keeps your supplied narration as the master audio track.

## Add your voice
Put your final narration file here:

`assets/voiceover.m4a`

The current workflow expects that exact filename. Your recording is not embedded in this ZIP because the chat audio attachment was not available as a downloadable project file in the build environment. Copy the same `jet engine.m4a` recording into the `assets` folder and rename it `voiceover.m4a`.

## Render on GitHub
1. Create a new GitHub repository.
2. Upload the contents of this ZIP (not the ZIP itself).
3. Add `assets/voiceover.m4a`.
4. Open **Actions** → **Render Jet Engine Short** → **Run workflow**.
5. When it finishes, download the `jet-engine-short` artifact.

## Render locally
You need Blender 4.x and FFmpeg installed.

```bash
blender -b -P scripts/create_scene.py
python3 scripts/make_audio.py
ffmpeg -y -framerate 30 -i render/frame_%04d.png -i assets/voiceover.m4a \
  -i render/music_sfx.wav -filter_complex "[1:a]volume=1.0[voice];[2:a]volume=0.32[music];[voice][music]amix=inputs=2:duration=first:dropout_transition=0[a]" \
  -map 0:v -map "[a]" -c:v libx264 -pix_fmt yuv420p -r 30 -c:a aac -shortest output/jet-engine-short.mp4
```

## Important
This is version 0.1: it establishes the render pipeline and a procedural 3D jet-engine scene. The scene timing is a first pass and should be refined against the exact spoken words after the first render. The project is designed so later machine topics can use separate scene scripts and timing files.
