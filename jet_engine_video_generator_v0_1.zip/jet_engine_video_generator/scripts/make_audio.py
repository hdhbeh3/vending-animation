# Creates a simple original cinematic music/SFX bed using numpy + wave.
# No third-party audio packages are required.
import math, wave, os
import numpy as np

DURATION = 25.6
SR = 48000
n = int(DURATION * SR)
t = np.arange(n, dtype=np.float64) / SR
rng = np.random.default_rng(7)

# Low cinematic drone with a gentle build
music = (0.10*np.sin(2*np.pi*55*t) +
         0.045*np.sin(2*np.pi*82.4*t) +
         0.025*np.sin(2*np.pi*110*t))
pulse = 0.65 + 0.35*np.sin(2*np.pi*1.2*t)**2
build = np.clip(t/7.0,0,1) * 0.65 + 0.35
music *= pulse * build

# Airy noise bed, gently filtered by a moving envelope
noise = rng.normal(0,1,n)
# lightweight one-pole smoothing
smooth = np.empty_like(noise); smooth[0]=noise[0]
for i in range(1,n):
    smooth[i] = 0.985*smooth[i-1] + 0.015*noise[i]
music += smooth * (0.012 + 0.012*np.clip(t/20,0,1))

sfx = np.zeros(n, dtype=np.float64)
def add_whoosh(start, length, amp=0.22, pitch=90):
    a=int(start*SR); b=min(n,int((start+length)*SR))
    if b<=a:return
    tt=np.arange(b-a)/SR
    env=np.sin(np.pi*np.clip(tt/length,0,1))**1.5
    raw=np.sin(2*np.pi*(pitch*tt + 20*tt*tt)) + 0.35*rng.normal(0,1,b-a)
    sfx[a:b] += amp*env*raw
def add_hit(start, amp=0.3):
    a=int(start*SR); length=int(0.55*SR); b=min(n,a+length)
    if b<=a:return
    tt=np.arange(b-a)/SR
    sfx[a:b] += amp*np.exp(-tt*8)*(np.sin(2*np.pi*48*tt)+0.4*np.sin(2*np.pi*92*tt))

# Timed to the jet-engine explanation
add_whoosh(0.0,1.4,0.18,65)       # hook reveal
add_whoosh(3.0,2.0,0.14,110)      # intake air
add_whoosh(7.8,1.4,0.12,180)     # compressor
add_hit(11.0,0.25)                # ignition
add_whoosh(14.0,2.2,0.20,150)    # turbine spin-up
add_whoosh(19.0,3.0,0.25,75)    # exhaust rush
add_hit(23.0,0.18)

# Voice remains dominant; normalize music/SFX bed conservatively.
bed = music + sfx
peak = np.max(np.abs(bed))
if peak > 0: bed = bed * (0.72/peak)
bed = np.clip(bed, -0.95, 0.95)
pcm = (bed*32767).astype(np.int16)

os.makedirs("render",exist_ok=True)
with wave.open("render/music_sfx.wav","wb") as wf:
    wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes(pcm.tobytes())
print("Wrote render/music_sfx.wav")
