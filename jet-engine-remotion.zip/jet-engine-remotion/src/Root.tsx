import {Composition} from 'remotion';
import {Video} from './Video';

// 20 seconds at 30 fps = 600 frames (script: 0-3 hook, 3-8, 8-14, 14-20)
export const Root = () => (
  <Composition id="JetEngine" component={Video} durationInFrames={600} fps={30} width={1080} height={1920} />
);
