import {clamp, smooth} from './rig';

// ---- SCRIPT TIMING (frames at 30 fps) ------------------------------------
// 0-3 s    hook            -> frames 0-90   (whole engine, no labels)
// 3-8 s    fans suck air   -> frames 90-240
// 8-10.5 s compress        -> frames 240-315
// 10.5-14  fuel + ignite   -> frames 315-420
// 14-17 s  gases blast out -> frames 420-510
// 17-20 s  thrust, outro   -> frames 510-600
// ---------------------------------------------------------------------------

export type Callout = {
  id: string;
  lines: string[];
  anchor: [number, number]; // [position along the engine axis, radius]
  side: 'left' | 'right';
  s: number;
  e: number;
};

export const CALLOUTS: Callout[] = [
  {id: 'fan', lines: ['FAN'], anchor: [-2.35, 0.8], side: 'left', s: 90, e: 240},
  {id: 'comp', lines: ['COMPRESSOR'], anchor: [-1.3, 0.55], side: 'right', s: 240, e: 315},
  {id: 'inj', lines: ['FUEL', 'INJECTORS'], anchor: [-0.5, 0.52], side: 'left', s: 315, e: 420},
  {id: 'comb', lines: ['COMBUSTION', 'CHAMBER'], anchor: [0.1, 0.45], side: 'right', s: 315, e: 420},
  {id: 'turb', lines: ['TURBINE'], anchor: [1.1, 0.5], side: 'left', s: 420, e: 510},
  {id: 'noz', lines: ['EXHAUST', 'NOZZLE'], anchor: [2.7, 0.35], side: 'right', s: 420, e: 510},
  {id: 'thr', lines: ['THRUST'], anchor: [0.5, 1.75], side: 'left', s: 510, e: Infinity},
];

const SEGS = [
  {s: 90, e: 240, parts: ['fan']},
  {s: 240, e: 315, parts: ['comp']},
  {s: 315, e: 420, parts: ['inj', 'comb']},
  {s: 420, e: 510, parts: ['turb', 'nozzle']},
];

// how strongly the machine is dimmed to put the spotlight on the active part(s)
export const focus = (f: number) => smooth((f - 80) / 15) * (1 - smooth((f - 510) / 30));

// 0..1: is this part the one being explained right now
export const act = (part: string, f: number) =>
  Math.max(0, ...SEGS.filter((g) => g.parts.includes(part)).map((g) => smooth((f - g.s + 6) / 12) * smooth((g.e + 6 - f) / 12)));

export const labelOpacity = (c: Callout, f: number) => {
  if (f < c.s || f >= c.e) return 0;
  return smooth((f - c.s) / 9) * (c.e === Infinity ? 1 : smooth((c.e - f) / 9));
};

export const ignite = (f: number) => clamp((f - 318) / 20);
