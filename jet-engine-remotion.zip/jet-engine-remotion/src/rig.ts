import * as THREE from 'three';

export const HOLD_START = 570; // camera, pulses and labels are completely still from here (last 1 s)
export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const smooth = (t: number) => {
  t = clamp(t);
  return t * t * (3 - 2 * t);
};
export const easeOut = (t: number) => 1 - Math.pow(1 - clamp(t), 3);

export const ROT = 1.3; // engine tilted nearly vertical so it fills a 9:16 frame
export const A0 = -0.43; // radial angle of the cutaway's centre (faces the camera)
export const PHI0 = 1.216; // lathe start angle that puts the cutaway at A0
export const ENGINE_M = new THREE.Matrix4().makeRotationZ(ROT);

export const camAt = (frame: number) => {
  const e = easeOut(Math.min(frame, HOLD_START) / HOLD_START);
  const a = 0.15 + 0.65 * e;
  const r = 18.5 - 0.8 * e;
  return {pos: [Math.sin(a) * r, 7, Math.cos(a) * r] as [number, number, number], look: [0, 1.2, 0] as [number, number, number]};
};

export const makeCamera = (frame: number) => {
  const c = new THREE.PerspectiveCamera(35, 1080 / 1920, 0.1, 100);
  const {pos, look} = camAt(frame);
  c.position.set(...pos);
  c.lookAt(...look);
  c.updateProjectionMatrix();
  c.updateMatrixWorld();
  return c;
};

// spin / pulse clock: runs normally, then eases to a stop between frame 540 and 570
export const clockAt = (f: number) => {
  if (f < 540) return f;
  const t = clamp((f - 540) / 30);
  return 540 + 30 * (t - (t * t) / 2);
};
